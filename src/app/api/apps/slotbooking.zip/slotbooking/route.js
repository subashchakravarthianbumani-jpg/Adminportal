import path from 'path';

import jwt from 'jsonwebtoken'; // Use jwt library for token validation

import { format } from 'date-fns'; // Date formatting for SQL insert

import nodemailer from 'nodemailer'; // Use nodemailer for sending emails

import QRCode from 'qrcode';

// import db from '../db'; // Ensure you have the correct database connection file

import getDb from '../db'; // Import the singleton connection pool

const db = getDb(); // Get the shared connection pool

const SECRET_KEY = process.env.SECRET_KEY // Replace with your secret key

const logoPath = path.join(__dirname, '..','..','..','..','..', '..', 'public', 'images', 'logos', 'logo.png');

// Middleware to validate JWT token
const validateToken = async req => {
  const authHeader = req.headers.get('authorization')
  const token = authHeader && authHeader.split(' ')[1] // Bearer <token>

  if (!token) {
    throw new Error('Unauthorized')
  }

  try {
    const decoded = jwt.verify(token, SECRET_KEY, { algorithms: ['HS256'] })

    // Optionally: Check if token is active in the database
    const [rows] = await db.query('SELECT * FROM tokens WHERE Token = ? AND IsActive = 1', [token])

    if (!rows.length) {
      throw new Error('Unauthorized')
    }

    return decoded // Return decoded user info
  } catch (err) {
    console.error('Error during token validation:', err.message)
    throw new Error('Unauthorized')
  }
}

// API route for Slot Booking (POST method)
export async function POST(req) {
  try {
    // Validate token
    const user = await validateToken(req)

    const { StallApprove, SlotId, Isbooked, RegistrationId, SavedBy, SavedUserName } = await req.json() // Parse request body

    // Validate required fields based on the operation
    if (!StallApprove || !SavedBy || !SavedUserName) {
      return new Response(
        JSON.stringify({
          status: false,
          message: "'StallApprove', 'SavedBy', and 'SavedUserName' are required."
        }),
        { status: 400 }
      )
    }

    const validateQuery = `
      SELECT
        (SELECT COUNT(*) FROM slotmaster WHERE Id = ?) AS SlotExists,
        (SELECT COUNT(*) FROM registrationmaster WHERE Id = ?) AS RegistrationExists,
        (SELECT COUNT(*) FROM usermaster WHERE Id = ? AND UserName = ?) AS UserExists
    `

    const [validationResults] = await db.query(validateQuery, [SlotId, RegistrationId, SavedBy, SavedUserName])

    const { SlotExists, RegistrationExists, UserExists } = validationResults[0]

    if (SlotId && SlotExists === 0) {
      return new Response(
        JSON.stringify({
          status: false,
          message: "Invalid 'SlotId'. It does not exist in the slotmaster table."
        }),
        { status: 400 }
      )
    }

    if (RegistrationId && RegistrationExists === 0) {
      return new Response(
        JSON.stringify({
          status: false,
          message: "Invalid 'RegistrationId'. It does not exist in the registrationmaster table."
        }),
        { status: 400 }
      )
    }

    if (UserExists === 0) {
      return new Response(
        JSON.stringify({
          status: false,
          message: "Invalid 'SavedBy' or 'SavedUserName'. They do not match in the usermaster table."
        }),
        { status: 400 }
      )
    }

    // Save the booking or approval
    const now = new Date()
    const SavedDate = format(now, 'yyyy-MM-dd HH:mm:ss')

    const formatDate = (date) => {
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
      const year = date.getFullYear();
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');

      return `${day}-${month}-${year} ${hours}:${minutes}`;
  };

    const params = [
      StallApprove || 0,
      SlotId || null,
      Isbooked || 0,
      RegistrationId || null,
      SavedBy || null,
      SavedDate,
      SavedUserName || null
    ]

    console.log('Params:', params)

    const sql = 'CALL Settings_SP_ApproveSaveSlotSelection(?, ?, ?, ?, ?, ?, ?)'

    const [results] = await db.query(sql, params)

    console.log('Results:', results)

    const procedureResult = results[0][0]
    const messageKey = Object.keys(procedureResult)[0]
    const messageValue = procedureResult[messageKey]


    const Registration = 'SELECT * FROM registrationmaster WHERE 	Id = ?'
    const [results2] = await db.query(Registration, [RegistrationId])
    const registration = results2[0];


    if(messageValue) {
      if(messageValue == 'Booking successful') {
        const slot = 'SELECT * FROM slotmaster WHERE Id = ?'
        const [results1] = await db.query(slot,[SlotId])
        const slotbooked = results1[0]
        const DateTime = formatDate(new Date());


    const messageText = `Hi ${registration.FirstName}, you've completed the Stall Booking Registration confirmed successfully on ${DateTime} -TAHDCO`;

          console.log("messageText:", messageText);

          const smsApiUrl = `http://panel.smsmessenger.in/api/mt/SendSMS?user=tahdco&password=T@hdc0&senderid=TAHDCO&channel=Trans&DCS=0&flashsms=0&number=${registration.Phone}&text=${encodeURIComponent(messageText)}&route=6&peid=1101634270000046830&DLTTemplateId=1107172778136171249`;

          console.log("smsApiUrl:", smsApiUrl);
          let htmlContent='';



          // Send SMS via API
                    try {
                        const smsResponse = await fetch(smsApiUrl, { method: 'GET' });
                        const smsResult = await smsResponse.json();

                        if (smsResult.ErrorCode !== '0') {
                            console.error('SMS sending failed:', smsResult.ErrorMessage);
                        } else {
                            console.log('SMS sent successfully!');
                        }
                    } catch (error) {
                        console.error('Error sending SMS:', error);
                    }

                    if(registration.Email != '' || registration.Email != null) {
                                const to = registration.Email;
                                const subject = 'TN-BEAT EXPO Stall confirmation';
                                const qrData = `https://eventreg.tahdco.com/#/idcard/${registration.RegitrationNo}`;
                                const qrCodeDataUri = await QRCode.toDataURL(qrData); // Generate QR code as a Data URI
                                const StallDateTime = formatDate(registration.CreatedDate);

                                htmlContent = `<p id="hi"> Dear ${registration.FirstName},</p>
              <p id='para'>Thanks, for your registration. The stall has been approved. The details are below:</p>
              <table>
              <tr>
              <td>Registration Number</td>
              <td>:<b>${registration.RegitrationNo}</b></td>
              </tr>
              <tr>
              <td>Registration Type.</td>
              <td>:<b>${registration.RegitrationType}</b></td>
              </tr>
              <tr>
              <td>Registration Date and Time</td>
              <td>:<b>${StallDateTime}</b></td>
              </tr>
              <tr>
              <td>Registration Status</td>
              <td>:<b>Active</b></td>
              </tr>
              </table>
              <br>
              <table>
              <tr>
              <td>EXPO Dates</td>
              <td>:<b>25<sup>th</sup> and 26<sup>th</sup> January, 2025</b></td>
              </tr>
              <tr>
              <td>EXPO Venue</td>
              <td>:<b>Chennai Trade Centre – Nandambakkam, Chennai - 600089</b></td>
              </tr>
              </table>
              <p>If you have any questions, Please reach out TN-BEAT EXPO management.</p><br>
                    <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: #f3f4f6; margin: 0;" class="dummy" id="dummy">
                <!-- Registration Form Container -->
                <div style="background-color: white; border-radius: 12px; box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); width: 90%; max-width: 477px; margin-bottom: 16px;">
                  <!-- Image Section -->
                  <div style="text-align: center; margin-bottom: 24px;">
                    <img src="cid:logo" alt="Form Illustration" style="max-width: 100%; height: auto; max-width: 377px;" />
                  </div>

                  <!-- Header Section -->
                  <div style="background: linear-gradient(90deg, #040E56 0%, #006D5D 100%); color: white; font-size: 20px; font-weight: bold; text-align: center; padding: 16px 0 59px; line-height: 1.55rem; margin-bottom: 24px;">
                    Tamilnadu Adi Dravidar Housing & Development Corporation
                  </div>

                 <!-- QR Code Section -->
                    <div style="text-align: center; margin-top: -30px;"> <!-- Adjusted margin for QR Code -->
                        <!-- QR Code -->
                        <div style="width: 200px; height: 200px; border-radius: 10px; border: 15px solid white; background-image: url('cid:qrcode'); background-repeat: no-repeat; background-size: cover; background-position: center; margin: 0 auto;"></div>

                        <!-- Name -->
                        <div style="font-weight: 700; font-size: 36px; text-align: center; margin-top: 24px; color: #000;">
                            ${registration.FirstName} ${registration.LastName}
                        </div>

                        <!-- Registration ID -->
                        <div style="font-family: 'Alice', serif; font-size: 30px; line-height: 40px; text-align: center; margin-top: 8px;">
                            ${registration.RegitrationNo}
                        </div>
                    </div>

                  <!-- Footer Section -->
                  <div style="background: linear-gradient(90deg, #040E56 0%, #006D5D 100%); color: white; font-family: 'Archivo Black', sans-serif; font-weight: 700; font-size: 20px; text-align: center; padding: 8px 0; margin-top: 16px;">
                    ${registration.RegitrationType}
                </div>
                </div>
              </div><br>
                    <p>Thanks,</p>
                    <p>TN-BEAT EXPO 2025 2<sup>nd</sup> Edition</p>
                    <p>Contact: 94450 29534  |  91502 77736</p><br>
                    <p>TAHDCO - Tamil Nadu Adi Dravidar Housing & Development Corporation Ltd</p>
                    <p> #31, Cenotaph Road, Teynampet, Chennai - 600018</p>
                  `

                              try {
                                 // Set up Nodemailer transporter
                                    const transporter = nodemailer.createTransport({
                                      host: process.env.SMTP_HOST, // Your SMTP host
                                      port: process.env.SMTP_PORT, // SMTP port (e.g., 587)
                                      secure: process.env.SMTP_SECURE === 'true', // true for 465, false for other ports
                                      auth: {
                                        user: process.env.SMTP_USER, // Your email address
                                        pass: process.env.SMTP_PASS, // Your email password
                                      },
                                    });

                                    // Send email
                                    const emailInfo = await transporter.sendMail({
                                      from: `"TN-BEAT EXPO" <${process.env.SMTP_USER}>`, // Sender address
                                      to, // Receiver address
                                      subject, // Subject line
                                      html: htmlContent,
                                      attachments: [
                                        {
                                          filename: 'qrcode.png',
                                          content: qrCodeDataUri.split(',')[1], // Extract base64 part of QR code
                                          encoding: 'base64',
                                          cid: 'qrcode', // Content ID for inline attachment
                                        },

                                        {
                                          filename: 'logo.png',
                                          path: logoPath, // Direct path to the logo image in the public folder
                                          cid: 'logo', // Content ID for inline attachment
                                        }
                                      ],
                                    });


                                    console.log('Email sent successfully:', emailInfo.messageId);
                              } catch (error) {
                                console.error('Error in Email :', error.message);

                              }
                            }
      }

      if(messageValue == 'Registration rejected and slot unbooked') {
        // const slot = 'SELECT * FROM slotmaster WHERE Id = ?'
        // const [results1] = await db.query(slot,[SlotId])
        // const slotbooked = results1[0]
        const DateTime = formatDate(new Date());

        const status = 'Rejected'; // Example status
        const additionalDetails = 'Your application does not meet the eligibility criteria.';

          //const messageText = `Hi ${registration.FirstName}, your Stall Booking Registration ${slotbooked.SlotNumber} has been rejected on ${DateTime} -TAHDCO`;
          const messageText = `Your application ${registration.RegitrationNo} status is ${status}. ${additionalDetails}. -TAHDCO`;

          console.log("messageText:", messageText);

          const smsApiUrl = `http://panel.smsmessenger.in/api/mt/SendSMS?user=tahdco&password=T@hdc0&senderid=TAHDCO&channel=Trans&DCS=0&flashsms=0&number=${registration.Phone}&text=${encodeURIComponent(messageText)}&route=6&peid=1107168267236448856&DLTTemplateId=1107168267231976704`;

          console.log("smsApiUrl:", smsApiUrl);
          let htmlContent='';

          // Send SMS via API
                    try {
                        const smsResponse = await fetch(smsApiUrl, { method: 'GET' });
                        const smsResult = await smsResponse.json();

                        if (smsResult.ErrorCode !== '0') {
                            console.error('SMS sending failed:', smsResult.ErrorMessage);
                        } else {
                            console.log('SMS sent successfully!');
                        }
                    } catch (error) {
                        console.error('Error sending SMS:', error);
                    }

                    if(registration.Email != '' || registration.Email != null) {
                      const to = registration.Email;
                      const subject = 'TN-BEAT EXPO Stall Cancelled';
                      const qrData = `https://eventreg.tahdco.com/#/idcard/${registration.RegitrationNo}`;
                      const qrCodeDataUri = await QRCode.toDataURL(qrData); // Generate QR code as a Data URI
                      const StallDateTime = formatDate(registration.CreatedDate);

                      htmlContent = `<p id="hi"> Dear ${registration.FirstName},</p>
    <p id='para'>Thanks, for your registration. Unfortunately, the stall allocation has been cancelled. The details are below:</p>
    <table>
    <tr>
    <td>Registration Number</td>
    <td>:<b>${registration.RegitrationNo}</b></td>
    </tr>
    <tr>
    <td>Registration Type.</td>
    <td>:<b>${registration.RegitrationType}</b></td>
    </tr>
    <tr>
    <td>Registration Date and Time</td>
    <td>:<b>${StallDateTime}</b></td>
    </tr>
    <tr>
    <td>Registration Status</td>
    <td>:<b>Cancelled</b></td>
    </tr>
    </table>
    <br>
    <table>
    <tr>
    <td>EXPO Dates</td>
    <td>:<b>25<sup>th</sup> and 26<sup>th</sup> January, 2025</b></td>
    </tr>
    <tr>
    <td>EXPO Venue</td>
    <td>:<b>Chennai Trade Centre – Nandambakkam, Chennai - 600089</b></td>
    </tr>
    </table>
    <p>If you have any questions, Please reach out TN-BEAT EXPO management.</p><br>
          <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: #f3f4f6; margin: 0;" class="dummy" id="dummy">
      <!-- Registration Form Container -->
      <div style="background-color: white; border-radius: 12px; box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); width: 90%; max-width: 477px; margin-bottom: 16px;">
        <!-- Image Section -->
        <div style="text-align: center; margin-bottom: 24px;">
          <img src="cid:logo" alt="Form Illustration" style="max-width: 100%; height: auto; max-width: 377px;" />
        </div>

        <!-- Header Section -->
        <div style="background: linear-gradient(90deg, #040E56 0%, #006D5D 100%); color: white; font-size: 20px; font-weight: bold; text-align: center; padding: 16px 0 59px; line-height: 1.55rem; margin-bottom: 24px;">
          Tamilnadu Adi Dravidar Housing & Development Corporation
        </div>

       <!-- QR Code Section -->
          <div style="text-align: center; margin-top: -30px;"> <!-- Adjusted margin for QR Code -->
              <!-- QR Code -->
              <div style="width: 200px; height: 200px; border-radius: 10px; border: 15px solid white; background-image: url('cid:qrcode'); background-repeat: no-repeat; background-size: cover; background-position: center; margin: 0 auto;"></div>

              <!-- Name -->
              <div style="font-weight: 700; font-size: 36px; text-align: center; margin-top: 24px; color: #000;">
                  ${registration.FirstName} ${registration.LastName}
              </div>

              <!-- Registration ID -->
              <div style="font-family: 'Alice', serif; font-size: 30px; line-height: 40px; text-align: center; margin-top: 8px;">
                  ${registration.RegitrationNo}
              </div>
          </div>

        <!-- Footer Section -->
        <div style="background: linear-gradient(90deg, #040E56 0%, #006D5D 100%); color: white; font-family: 'Archivo Black', sans-serif; font-weight: 700; font-size: 20px; text-align: center; padding: 8px 0; margin-top: 16px;">
          ${registration.RegitrationType}
      </div>
      </div>
    </div><br>
          <p>Thanks,</p>
          <p>TN-BEAT EXPO 2025 2<sup>nd</sup> Edition</p>
          <p>Contact: 94450 29534  |  91502 77736</p><br>
          <p>TAHDCO - Tamil Nadu Adi Dravidar Housing & Development Corporation Ltd</p>
          <p> #31, Cenotaph Road, Teynampet, Chennai - 600018</p>
        `

                    try {
                       // Set up Nodemailer transporter
                          const transporter = nodemailer.createTransport({
                            host: process.env.SMTP_HOST, // Your SMTP host
                            port: process.env.SMTP_PORT, // SMTP port (e.g., 587)
                            secure: process.env.SMTP_SECURE === 'true', // true for 465, false for other ports
                            auth: {
                              user: process.env.SMTP_USER, // Your email address
                              pass: process.env.SMTP_PASS, // Your email password
                            },
                          });

                          // Send email
                          const emailInfo = await transporter.sendMail({
                            from: `"TN-BEAT EXPO" <${process.env.SMTP_USER}>`, // Sender address
                            to, // Receiver address
                            subject, // Subject line
                            html: htmlContent,
                            attachments: [
                              {
                                filename: 'qrcode.png',
                                content: qrCodeDataUri.split(',')[1], // Extract base64 part of QR code
                                encoding: 'base64',
                                cid: 'qrcode', // Content ID for inline attachment
                              },

                              {
                                filename: 'logo.png',
                                path: logoPath, // Direct path to the logo image in the public folder
                                cid: 'logo', // Content ID for inline attachment
                              }
                            ],
                          });


                          console.log('Email sent successfully:', emailInfo.messageId);
                    } catch (error) {
                      console.error('Error in Email :', error.message);

                    }
                  }


      }
    }

    console.log(procedureResult);

    switch (messageValue) {
      case 'Unapproved and Unbooked':
        return new Response(
          JSON.stringify({
            status: true,
            message: 'Registration unapproved and associated slot unbooked successfully.'
          }),
          { status: 200 }
        )

      case 'Registration approved':
        return new Response(
          JSON.stringify({
            status: true,
            message: 'Registration approved successfully.'
          }),
          { status: 200 }
        )

      case 'Booking successful':
        return new Response(
          JSON.stringify({
            status: true,
            message: 'Slot booked successfully.'
          }),
          { status: 200 }
        )

      case 'Slot already booked':
        return new Response(
          JSON.stringify({
            status: false,
            message: 'Slot booking failed. The selected slot is already booked.'
          }),
          { status: 400 }
        )

      case 'Already Booked':
        return new Response(
          JSON.stringify({
            status: false,
            message: 'Slot booking failed. The registration ID is already associated with another slot.'
          }),
          { status: 400 }
        )

      case 'Unbooking successful':
        return new Response(
          JSON.stringify({
            status: true,
            message: 'Slot unbooked successfully.'
          }),
          { status: 200 }
        )

      case 'Slot Not Booked':
        return new Response(
          JSON.stringify({
            status: false,
            message: 'Slot unbooking failed. The slot was not booked.'
          }),
          { status: 400 }
        )

      case 'Not Approved':
        return new Response(
          JSON.stringify({
            status: false,
            message: 'The registration is not approved.'
          }),
          { status: 400 }
        )

      case 'Booking Not Allowed':
        return new Response(
          JSON.stringify({
            status: false,
            message: 'Booking is not allowed for the registration.'
          }),
          { status: 400 }
        )

      case 'Already Approved':
        return new Response(
          JSON.stringify({
            status: false,
            message: 'The registration is already approved.'
          }),
          { status: 400 }
        )

      case 'Slot Is Not Available':
        return new Response(
          JSON.stringify({
            status: false,
            message: 'The selected slot is not available for booking.'
          }),
          { status: 400 }
        )

      case 'Approval Pending':
        return new Response(
          JSON.stringify({
            status: false,
            message: 'The registration approval is pending.'
          }),
          { status: 400 }
        )

      case 'Slot canceled':
        return new Response(
          JSON.stringify({
            status: true,
            message: 'Slot canceled successfully.'
          }),
          { status: 200 }
        )

        case 'Registration rejected and slot unbooked':
          return new Response(
            JSON.stringify({
              status: true,
              message: 'Rejected successfully.'
            }),
            { status: 200 }
          )

          case 'Registration restored':
            return new Response(
              JSON.stringify({
                status: true,
                message: 'Restored successfully.'
              }),
              { status: 200 }
            )

      default:
        return new Response(
          JSON.stringify({
            status: false,
            message: messageValue
          }),
          { status: 500 }
        )
    }
  } catch (err) {
    console.error('Error in POST API:', err.message)

    return new Response(
      JSON.stringify({
        status: false,
        message: err.message || 'Internal Server Error'
      }),
      { status: err.status || 500 }
    )
  }
}
