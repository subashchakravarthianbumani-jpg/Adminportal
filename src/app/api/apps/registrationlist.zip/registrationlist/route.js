import jwt from 'jsonwebtoken' // Use jwt library for token validation

import { format } from 'date-fns' // Date formatting for SQL insert

// import db from '../db' // Ensure you have the correct database connection file
import getDb from '../db'; // Import the singleton connection pool

const db = getDb(); // Get the shared connection pool

const SECRET_KEY = process.env.SECRET_KEY // Replace with your secret key

// Middleware to validate JWT token
const validateToken = async req => {
  const authHeader = req.headers.get('authorization')
  const token = authHeader && authHeader.split(' ')[1] // Bearer <token>

  if (!token) {
    throw new Error('Unauthorized')
  }

  try {
    const decoded = jwt.verify(token, SECRET_KEY, { algorithms: ['HS256'] })

    // Optionally: Check if token is active in the database
    const [rows] = await db.query('SELECT * FROM tokens WHERE Token = ? AND IsActive = 1', [token])

    if (!rows.length) {
      throw new Error('Unauthorized')
    }

    return decoded // Return decoded user info
  } catch (err) {
    console.error('Error during token validation:', err.message)
    throw new Error('Unauthorized')
  }
}

// API Route to handle the GET request
export async function GET(req) {
  if (req.method !== 'GET') {
    return new Response(JSON.stringify({ status: false, message: 'Method Not Allowed' }), { status: 405 })
  }

  try {
    // Validate token
    const user = await validateToken(req)

    // Base SQL query
    let sql = `
      SELECT SQL_CALC_FOUND_ROWS rm.*,
           gd1.DropDownValue AS GenderName,
           gd2.DropDownValue AS CommunityName,
           gd3.DropDownValue AS DistrictName,
           gd4.DropDownValue AS StateName,
           gd5.DropDownValue AS ReferenceByName,
           gd6.DropDownValue AS VisitorCategoryName,
           gd7.DropDownValue AS BusinessCategoryName,
           gd8.DropDownValue AS OthersCategoryName,
           gd9.DropDownValue AS IntrestedSectorName,
           gd10.DropDownValue AS SessionName,
           gd11.DropDownValue AS SeminarName,
           CASE
           WHEN rm.IsStallApprove = 0 THEN 'Rejected'
           WHEN rm.IsStallApprove = 1 THEN 'Approved'
           WHEN rm.IsStallApprove IS NULL THEN 'Waiting'
           END AS StallApprovalStatus,
           sm.Id AS SlotId,
           sm.SlotNumber AS SlotNumber,
           sm.SlotName AS SlotName
    FROM registrationmaster rm
    LEFT JOIN dropdownmaster gd1 ON rm.Gender = gd1.Id
    LEFT JOIN dropdownmaster gd2 ON rm.Community = gd2.Id
    LEFT JOIN dropdownmaster gd3 ON rm.District = gd3.Id
    LEFT JOIN dropdownmaster gd4 ON rm.State = gd4.Id
    LEFT JOIN dropdownmaster gd5 ON rm.ReferenceBy = gd5.Id
    LEFT JOIN dropdownmaster gd6 ON rm.VisitorCategory = gd6.Id
    LEFT JOIN dropdownmaster gd7 ON rm.BusinessCategory = gd7.Id
    LEFT JOIN dropdownmaster gd8 ON rm.OthersCategory = gd8.Id
    LEFT JOIN dropdownmaster gd9 ON rm.IntrestedSector = gd9.Id
    LEFT JOIN dropdownmaster gd10 ON rm.Session = gd10.Id
    LEFT JOIN dropdownmaster gd11 ON rm.Seminars = gd11.Id
    LEFT JOIN slotmaster sm ON rm.Id = sm.RegistrationId
    WHERE 1=1`

    const params = []

    // const filters = req.params || {}
    const filters = Object.fromEntries(req.nextUrl.searchParams.entries())

    // Debugging: Log the filters object to verify query parameters
    console.log('Filters:', filters)

    // Dynamically build the query
    Object.keys(filters).forEach(key => {
      const value = filters[key]

      // if (value !== undefined && value !== '') {
      //   sql += ` AND rm.${key} = ?`
      //   params.push(value)
      // }

      if (value === 'NULL') {
        if( key === 'SlotId' || key === 'SlotNumber' || key === 'SlotName') {
          sql += ` AND sm.${key} IS NULL`
        }else {

        // Handle null values
        sql += ` AND rm.${key} IS NULL`
        }
      } else if (value !== undefined && value !== '') {
        if( key === 'SlotId' || key === 'SlotNumber' || key === 'SlotName') {
          sql += ` AND sm.${key} = ?`
        }else {

        // Handle non-null values
        sql += ` AND rm.${key} = ?`
        }

        params.push(value)
      }
    })

    // Debugging: Log the final SQL query and params to verify
    console.log('SQL Query:', sql)
    console.log('Query Params:', params)

    // Execute the query
    const [results] = await db.query(sql, params)

    // Get the total count
    const [countResult] = await db.query('SELECT FOUND_ROWS() AS totalCount')
    const totalCount = countResult[0]?.totalCount || 0

    // If no results, return not found
    if (!results.length) {
      return new Response(JSON.stringify({ status: false, message: 'Data not found.', totalCount }), { status: 200 })
    }

    // Return the results
    return new Response(JSON.stringify({ status: true, data: results, totalCount }), { status: 200 })
  } catch (err) {
    console.error('Error executing query:', err)

    return new Response(JSON.stringify({ status: false, message: err.message || 'Internal Server Error' }), {
      status: 500
    })
  }
}

export default GET
