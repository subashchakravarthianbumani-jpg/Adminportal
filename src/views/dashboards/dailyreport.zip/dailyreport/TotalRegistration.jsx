"use client";

import React, { useState, useEffect, useMemo } from 'react';

import dynamic from 'next/dynamic';

import CardHeader from '@mui/material/CardHeader';
import MuiCard from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { styled } from '@mui/material/styles';

// Styled Card Component
const Card = styled(MuiCard)(({ color }) => ({
  transition: 'border 0.3s ease-in-out, box-shadow 0.3s ease-in-out, margin 0.3s ease-in-out',
  borderBottomWidth: '2px',
  borderBottomColor: `var(--mui-palette-${color}-darkerOpacity)`,
  '[data-skin="bordered"] &:hover': {
    boxShadow: 'none'
  },
  '&:hover': {
    borderBottomWidth: '3px',
    borderBottomColor: `var(--mui-palette-${color}-main) !important`,
    boxShadow: 'var(--mui-customShadows-xl)',
    marginBlockEnd: '-1px'
  }
}));

// Dynamically import ReactApexChart to avoid SSR issues
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false });

const TotalRegistration = ({ Category = [], Values = [] }) => {
  // Memoize the updated arrays to prevent unnecessary recalculations
  const updatedCategory = useMemo(() => Category.slice(1), [Category]);
  const updatedValues = useMemo(() => Values.slice(1), [Values]);

  const [state, setState] = useState({
    series: [
      {
        name: 'Categories',
        data: updatedValues,
      },
    ],
    options: {
      chart: {
        type: 'bar',
        height: 500,
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: '80%',
          borderRadius: 5,
          borderRadiusApplication: 'end',
          distributed: true,
        },
      },
      dataLabels: {
        enabled: true,
        formatter: val => val,
        style: {
          fontSize: '16px',
          fontWeight: 'bold',
        },
      },
      stroke: {
        show: true,
        width: 2,
        colors: ['transparent'],
      },
      xaxis: {
        categories: updatedCategory,
      },
      yaxis: {
        title: {
          text: 'Count',
        },
        min: 0,
        max: 10,
      },
      fill: {
        opacity: 1,
      },
      colors: ['#3366CC', '#DC3912', '#FF9900', '#006D5D', '#FFCC00', '#8E44AD', '#F39C12'],
    },
  });

  // Update the state only when updatedCategory or updatedValues change
  useEffect(() => {
    setState((prevState) => ({
      ...prevState,
      series: [
        {
          ...prevState.series[0],
          data: updatedValues,
        },
      ],
      options: {
        ...prevState.options,
        xaxis: {
          ...prevState.options.xaxis,
          categories: updatedCategory,
        },
      },
    }));
  }, []);

  const getCurrentDate = () => {

    const currentDate = new Date();

    return currentDate.toLocaleDateString('en-US', {
      weekday: undefined,
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).replace(',', ' ,');
  };

  return (
    <div>
      <div id="chart">
        <Card color="primary">
          <CardHeader
            title={`Business Categories as on ${getCurrentDate()}`}
            subheader={`Total Registration: ${updatedValues.reduce((a, b) => a + b, 0)}`}
            sx={{
              '& .MuiCardHeader-subheader': {
                fontWeight: 'bold',
                color: 'black',
              },
              '& .MuiCardHeader-title': {
                fontWeight: 'bold',
                color: 'black',
                marginBottom: '10px',
              },
            }}
          />
          <CardContent>
            <ReactApexChart options={state.options} series={state.series} type="bar" height={316} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TotalRegistration;
